Check that the argument that your function fets are the same as used in the test.
It's more than likly to be diffrent.